Hello.  This is the main page.  Maybe it has a calendar, or weekly
announcements, and links to assignments.

<python>
print(cs_username)
</python>
