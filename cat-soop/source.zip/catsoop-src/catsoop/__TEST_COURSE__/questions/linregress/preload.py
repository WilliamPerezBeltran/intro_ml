cs_long_name = "Linear Regression"
mode = "analysis"
