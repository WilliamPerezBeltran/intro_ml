cs_long_name = "Course Structure"
